﻿namespace DB_수행4_예상문제
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button_save = new System.Windows.Forms.Button();
            this.button_login_open = new System.Windows.Forms.Button();
            this.text_id = new System.Windows.Forms.TextBox();
            this.text_pwd1 = new System.Windows.Forms.TextBox();
            this.text_pwd2 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(24, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "아이디";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("굴림", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(24, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "암  호";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("굴림", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.Location = new System.Drawing.Point(24, 114);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "암호확인";
            // 
            // button_save
            // 
            this.button_save.Font = new System.Drawing.Font("굴림", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_save.Location = new System.Drawing.Point(279, 25);
            this.button_save.Name = "button_save";
            this.button_save.Size = new System.Drawing.Size(97, 113);
            this.button_save.TabIndex = 3;
            this.button_save.Text = "저장";
            this.button_save.UseVisualStyleBackColor = true;
            // 
            // button_login_open
            // 
            this.button_login_open.Font = new System.Drawing.Font("굴림", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button_login_open.Location = new System.Drawing.Point(26, 187);
            this.button_login_open.Name = "button_login_open";
            this.button_login_open.Size = new System.Drawing.Size(335, 39);
            this.button_login_open.TabIndex = 4;
            this.button_login_open.Text = "로그인하기";
            this.button_login_open.UseVisualStyleBackColor = true;
            // 
            // text_id
            // 
            this.text_id.Font = new System.Drawing.Font("굴림", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.text_id.Location = new System.Drawing.Point(117, 25);
            this.text_id.Name = "text_id";
            this.text_id.Size = new System.Drawing.Size(156, 30);
            this.text_id.TabIndex = 5;
            // 
            // text_pwd1
            // 
            this.text_pwd1.Font = new System.Drawing.Font("굴림", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.text_pwd1.Location = new System.Drawing.Point(117, 67);
            this.text_pwd1.Name = "text_pwd1";
            this.text_pwd1.Size = new System.Drawing.Size(156, 30);
            this.text_pwd1.TabIndex = 6;
            // 
            // text_pwd2
            // 
            this.text_pwd2.Font = new System.Drawing.Font("굴림", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.text_pwd2.Location = new System.Drawing.Point(117, 108);
            this.text_pwd2.Name = "text_pwd2";
            this.text_pwd2.Size = new System.Drawing.Size(156, 30);
            this.text_pwd2.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(391, 242);
            this.Controls.Add(this.text_pwd2);
            this.Controls.Add(this.text_pwd1);
            this.Controls.Add(this.text_id);
            this.Controls.Add(this.button_login_open);
            this.Controls.Add(this.button_save);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "회원가입";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button_save;
        private System.Windows.Forms.Button button_login_open;
        private System.Windows.Forms.TextBox text_id;
        private System.Windows.Forms.TextBox text_pwd1;
        private System.Windows.Forms.TextBox text_pwd2;
    }
}

