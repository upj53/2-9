﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_수행3_예상문제
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            /* 이곳의 코드를 완성하세요 */

            // 예상문제 1. 윈도우 폼에서
            // 이름(name), 학년(hak), 반(ban) 번호(bunho) 의 값을
            // 각각 변수에 저장하시오.

            // 이 코드는 수정하지 마시오.
            string birth = dateTimePicker1.Value.ToString("yyyy년 MM월 dd일 dddd"); 

            // 예상문제 2. 변수를 사용해서 다음과 예시와 같이 메시지 박스를 띄우시오.
            // 예시: "2학년 9반 25번 김성일 학생의 생일은 2007년 5월 23일 입니다."

        }
    }
}
